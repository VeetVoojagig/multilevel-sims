## SIMULATION & ANALYSIS OF CAUSALLY STRUCTURED MULTILEVEL DATA ----------------
## Written by Mark S Gilthorpe with input from Lydia Kakampakou
## Support from Andreas Hoehn for the reproducibility element

# ---------------------------------------------------------------------------- #
# R version 4.4.2 (2024-10-31 ucrt)
# parallel    --> part of base, simply load
# remotes     --> any new version
# MBESS       --> any new version, forcing versions might break OpenMx dependency
# MASS        --> 7.3-64
# tidyr       --> "1.3.1"
# dplyr       --> "1.1.4"
# dagitty     --> "0.3-4"
# data.table  --> "1.16.4"
# lme4        --> 1.1-36",
# ggplot2     --> "3.5.1"
# Matrix      --> "1.7-2"
# ---------------------------------------------------------------------------- #

# clear deep clean memory
rm(list=ls()) 
gc(full = TRUE)  

# start benchmarking time 
benchmark_time <- list() 
benchmark_time$start <- Sys.time()

# define specifically required packages and versions 
# + parallel(base)/remotes/MBESS any new version to avoid conflict
df_packages      <- data.frame(
  Package = c("MASS", "tidyr", "dplyr", "dagitty", "data.table", "lme4",
              "ggplot2", "Matrix"),
  Version = c("7.3-64", "1.3.1", "1.1.4", "0.3-4", "1.16.4", "1.1-36",
              "3.5.1", "1.7-2"))

# ensure all packages in their correct versions are installed and loaded 
.EnsurePackages <- function(df_packages) {
  library(parallel) # parallel is part of base R now
  # we install and download packages with "remotes::" --> slimmer than "devtools::"
  if (!requireNamespace("remotes", quietly = TRUE)) {   #
    install.packages("remotes")}
  # do not force install of particular version as there were issues with OpenMx
  if (!requireNamespace("MBESS", quietly = TRUE)) {  
    install.packages("MBESS")}
  # check and take action if required based on each row information
  for (i in 1:dim(df_packages)[1]){
    merged <- NULL # merged needs to be initialized and reset for each run
    packages_input <- df_packages[i,] # subset to be one dimensional 
    print(paste("checking", packages_input$Package, packages_input$Version))
    packages_installed <- data.frame(installed.packages()[, c("Package", "Version")])
    merged <- merge(packages_input, packages_installed, by = c("Package", "Version") )
    # if not present download package from CRAN in specified
      if (dim(merged)[1] == 0) {
          print(paste("need download/update package:",
                      packages_input$Package, packages_input$Version))
          remotes::install_version(package = packages_input$Package,
                                   version = packages_input$Version,
                                   quiet = TRUE ) } }
    # once check for each row has been carried out display what was loaded
    print("note: TRUE indicates required package in correct version is present and loaded")
    sapply(c(df_packages$Package,"remotes","MBESS","parallel"),
           suppressPackageStartupMessages(require),
           character.only = TRUE) }
.EnsurePackages(df_packages = df_packages)

## INITIALISE - SETUP PROGRAM CONFIGURATION DETAILS ----------------------------
# Setup parallel processing and packages for clusters (16 cores, 32 logical processors assumed for times)
numCore <- detectCores()                                                        # number of cores to parallel process
cl      <- makeCluster(numCore)                                                 # create clusters of cores 
clusterExport(cl, c(".EnsurePackages", "df_packages"))
invisible(clusterEvalQ(cl, {.EnsurePackages(df_packages = df_packages)} ))
invisible(clusterEvalQ(cl, { rm(list = c("pkgs")) } ) ) 

# Setup simulation parameters for main program
Configs   <- 1:4                                                                # number of dag configurations to run
OptN      <- 5  #5000                                                           # number of repeats for GenData (usually 500, 1k, or 5k)
OptSet    <- c("Opt_500", "Opt_1k", "Opt_5k")                                   # range of number of repeats for GenData
nSims     <- 50 #10^3                                                           # number or repeated simulations for main analyses
nPop      <- 1000 #10^5                                                         # population size
nClust    <- 50 #10^2                                                           # number of clusters
ClustSize <- round(nPop/nClust)                                                 # average cluster size
Nvar      <- ClustSize/10                                                       # cluster-size variance
YPrev     <- 0.1                                                                # main binary outcome prevalence 
LPrev     <- 0.1                                                                # main binary L-confounding prevalence 
LowPrev   <- 0.01 #0.001                                                        # low prevalence outcome value
vOrder    <- c("Z", "L", "N", "X", "Y")                                         # variable order
mu        <- c(0,0,0,0,0)                                                       # means for standardised data
var       <- c(1,1,1,1,1)                                                       # variances for standardised data
Means     <- as.numeric(mu)                                                     # format means correctly
nSeg      <- if_else (nSims > 10^2, 10, 1)                                      # nSims > 100 is segmented to save memory
Plots     <- paste0(getwd(),"/plots/")                                          # sub directory repository for plots
Results   <- paste0(getwd(),"/results/")                                        # sub directory repository for results

## FUNCTIONS  - GenData ALGORITHM ----------------------------------------------
# Simulate multivariate non-normal data using GenData1 for normal confounding & binary outcome
GenData1 <- function(N, k, Prev, Data.Cor, N.Factors, Max.Trials=5, Initial.Multiplier=1, seed) {
  ################################################################################################################
  # Initialize variables and (if applicable) set random number seed (step 1) -------------------------------------
  # N             <- dim(Supplied.Data)[1]        # Number of cases                                                   
  # k             <- dim(Supplied.Data)[2]        # Number of variables                                               
  Data          <- matrix(0, nrow=N, ncol=k)    # Matrix to store the simulated data                                
  Distributions <- matrix(0, nrow=N, ncol=k)    # Matrix to store each variable's score distribution                
  Iteration     <- 0                            # Iteration counter                                                 
  Best.RMSR     <- 1                            # Lowest RMSR correlation                                           
  Trials.Without.Improvement <- 0               # Trial counter                                                     
  if (seed != 0) set.seed(seed)                 # If user specified a nonzero seed, set it                          
  ################################################################################################################
  # Generate distribution for each variable (step 2) -------------------------------------------------------------
  # for (i in 1:k) Distributions[,i] <- sort(sample(Supplied.Data[,i], N, replace = TRUE))
  Distributions[,1] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,2] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,3] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,4] <- sort(rnorm(N,0,1))         # Standard normal distribution                         
  Distributions[,5] <- sort(rbinom(N,1,Prev))     # Binary distribution with p = YPrev                       
  # This implementation of GenData bootstraps each variable's score distribution from a supplied data set.        
  # Users should modify this block of the program, as needed, to generate the desired distribution(s).            
  ################################################################################################################
  # Calculate and store a copy of the target correlation matrix (step 3) -----------------------------------------
  # Target.Corr         <- cor(Supplied.Data)
  Target.Corr         <- Data.Cor
  Intermediate.Corr   <- Target.Corr
  # This implementation of GenData calculates the target correlation matrix from a supplied dataset.              
  # Alternatively, the user can modify the program to generate data with user-defined sample size, number of      
  # variables and target correlation matrix by redefining the function as follows:                                
  #   GenData <- function(N,k,Target.Corr,N.Factors=0,Max.Trials=5,Initial.Multiplier=1,seed=0)                   
  # In this case, one would also remove the program lines that calculate N, k, and Target.Corr.                   
  # To generate data in which variables are uncorrelated, one would remove the SsortT function from step 2        
  # and terminate the program before step 3 begins by returning the Distributions object as the dataset.          
  ################################################################################################################
  # If number of latent factors was not specified, determine it through parallel analysis (step 4) ---------------
  if (N.Factors == 0) {
    Eigenvalues.Observed  <- eigen(Intermediate.Corr)$values
    Eigenvalues.Random    <- matrix(0, nrow = 100, ncol = k)
    Random.Data           <- matrix(0, nrow = N,   ncol = k)
    for (i in 1:100) {
      for (j in 1:k) Random.Data[,j] <- sample(Distributions[,j], size = N, replace = TRUE)
      Eigenvalues.Random[i,] <- eigen(cor(Random.Data))$values }
    Eigenvalues.Random <- apply(Eigenvalues.Random, 2, mean)        # calculate mean eigenvalue for each factor     
    N.Factors <- max(1, sum(Eigenvalues.Observed > Eigenvalues.Random)) }
  ################################################################################################################
  # Generate random normal data for shared and unique components, initialize factor loadings (steps 5, 6) --------
  Shared.Comp <- matrix(rnorm(N*N.Factors, 0,1), nrow = N, ncol = N.Factors)
  Unique.Comp <- matrix(rnorm(N*k, 0,1), nrow = N, ncol = k)
  Shared.Load <- matrix(0, nrow =k, ncol = N.Factors)
  Unique.Load <- matrix(0, nrow =k, ncol = 1)
  ################################################################################################################
  # Begin loop that ends when specified number of iterations pass without improvement in RMSR correlation --------
  while (Trials.Without.Improvement < Max.Trials) {
    Iteration <- Iteration + 1
    ############################################################################################################
    # Calculate factor loadings and apply to reproduce desired correlations (steps 7, 8) -----------------------
    Fact.Anal <- Factor.Analysis(Intermediate.Corr, Corr.Matrix = TRUE, N.Factors = N.Factors)
    if (N.Factors == 1) Shared.Load[,1] <- Fact.Anal$loadings else 
      Shared.Load <- Fact.Anal$loadings
    Shared.Load[Shared.Load >  1] <-  1
    Shared.Load[Shared.Load < -1] <- -1
    if (Shared.Load[1,1] < 0) Shared.Load <- Shared.Load * -1
    Shared.Load.sq <- Shared.Load * Shared.Load
    for (i in 1:k)
      if (sum(Shared.Load.sq[i,]) < 1) Unique.Load[i,1] <- (1 - sum(Shared.Load.sq[i,])) else 
        Unique.Load[i,1] <- 0
    Unique.Load <- sqrt(Unique.Load)
    for (i in 1:k)
      Data[,i] <- (Shared.Comp %*% t(Shared.Load))[,i] + Unique.Comp[,i] * Unique.Load[i,1]
    # the %*% operator = matrix multiplication, and the t() function = transpose (both used again in step 13)   
    ############################################################################################################
    # Replace normal with non-normal distributions (step 9) ----------------------------------------------------
    for (i in 1:k) {
      Data <- Data[sort.list(Data[,i]),]
      Data[,i] <- Distributions[,i] }
    ############################################################################################################
    # Calculate RMSR correlation, compare to lowest value, take appropriate action (steps 10, 11, 12) ----------
    Reproduced.Corr <- cor(Data)
    Resid.Corr <- Target.Corr - Reproduced.Corr
    RMSR <- sqrt(sum(Resid.Corr[lower.tri(Resid.Corr)]*Resid.Corr[lower.tri(Resid.Corr)])/(0.5*(k*k-k)))
    if (RMSR < Best.RMSR) {
      Best.RMSR <- RMSR
      Best.Corr <- Intermediate.Corr
      Best.Res  <- Resid.Corr
      Intermediate.Corr <- Intermediate.Corr + Initial.Multiplier * Resid.Corr
      Trials.Without.Improvement <- 0 } else {
        Trials.Without.Improvement <- Trials.Without.Improvement + 1
        Current.Multiplier <- Initial.Multiplier * 0.5 ^ Trials.Without.Improvement
        Intermediate.Corr  <- Best.Corr + Current.Multiplier * Best.Res }
  } # end of the while loop
  ################################################################################################################
  # Construct the data set with the lowest RMSR correlation (step 13) --------------------------------------------
  Fact.Anal <- Factor.Analysis(Best.Corr, Corr.Matrix = TRUE, N.Factors = N.Factors)
  if (N.Factors == 1) Shared.Load[,1] <- Fact.Anal$loadings else 
    Shared.Load <- Fact.Anal$loadings
  Shared.Load[Shared.Load  > 1] <-  1
  Shared.Load[Shared.Load < -1] <- -1
  if (Shared.Load[1,1] < 0) Shared.Load <- Shared.Load * -1
  Shared.Load.sq <- Shared.Load * Shared.Load
  for (i in 1:k)
    if (sum(Shared.Load.sq[i,]) < 1) Unique.Load[i,1] <- (1 - sum(Shared.Load.sq[i,])) else 
      Unique.Load[i,1] <- 0
  Unique.Load <- sqrt(Unique.Load)
  for (i in 1:k)
    Data[,i] <- (Shared.Comp %*% t(Shared.Load))[,i] + Unique.Comp[,i] * Unique.Load[i,1]
  Data <- apply(Data, 2, scale)       # standardizes each variable in the matrix                                  
  for (i in 1:k) {
    Data <- Data[sort.list(Data[,i]),]
    Data[,i] <- Distributions[,i] }
  ################################################################################################################
  # Report the results and return the simulated data set (step 14) -----------------------------------------------
  Iteration <- Iteration - Max.Trials
  #cat("\nN =",N,", k =",k,",",Iteration,"Iterations,",N.Factors,"Factors, RMSR r =",round(Best.RMSR,3),"\n")
  return(Data) }

# Simulate multivariate non-normal data using GenData2 for binary confounding & continuous outcome
GenData2 <- function(N, k, Prev, Data.Cor, N.Factors, Max.Trials=5, Initial.Multiplier=1, seed) {
  ################################################################################################################
  # Initialize variables and (if applicable) set random number seed (step 1) -------------------------------------
  # N             <- dim(Supplied.Data)[1]        # Number of cases                                                   
  # k             <- dim(Supplied.Data)[2]        # Number of variables                                               
  Data          <- matrix(0, nrow=N, ncol=k)    # Matrix to store the simulated data                                
  Distributions <- matrix(0, nrow=N, ncol=k)    # Matrix to store each variable's score distribution                
  Iteration     <- 0                            # Iteration counter                                                 
  Best.RMSR     <- 1                            # Lowest RMSR correlation                                           
  Trials.Without.Improvement <- 0               # Trial counter                                                     
  if (seed != 0) set.seed(seed)                 # If user specified a nonzero seed, set it                          
  ################################################################################################################
  # Generate distribution for each variable (step 2) -------------------------------------------------------------
  # for (i in 1:k) Distributions[,i] <- sort(sample(Supplied.Data[,i], N, replace = TRUE))
  Distributions[,1] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,2] <- sort(rbinom(N,1,Prev))     # Binary distribution with p = LPrev                       
  Distributions[,3] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,4] <- sort(rnorm(N,0,1))         # Standard normal distribution                         
  Distributions[,5] <- sort(rnorm(N,0,1))         # Standard normal distribution                         
  # This implementation of GenData bootstraps each variable's score distribution from a supplied data set.        
  # Users should modify this block of the program, as needed, to generate the desired distribution(s).            
  ################################################################################################################
  # Calculate and store a copy of the target correlation matrix (step 3) -----------------------------------------
  # Target.Corr         <- cor(Supplied.Data)
  Target.Corr         <- Data.Cor
  Intermediate.Corr   <- Target.Corr
  # This implementation of GenData calculates the target correlation matrix from a supplied dataset.              
  # Alternatively, the user can modify the program to generate data with user-defined sample size, number of      
  # variables and target correlation matrix by redefining the function as follows:                                
  #   GenData <- function(N,k,Target.Corr,N.Factors=0,Max.Trials=5,Initial.Multiplier=1,seed=0)                   
  # In this case, one would also remove the program lines that calculate N, k, and Target.Corr.                   
  # To generate data in which variables are uncorrelated, one would remove the SsortT function from step 2        
  # and terminate the program before step 3 begins by returning the Distributions object as the dataset.          
  ################################################################################################################
  # If number of latent factors was not specified, determine it through parallel analysis (step 4) ---------------
  if (N.Factors == 0) {
    Eigenvalues.Observed  <- eigen(Intermediate.Corr)$values
    Eigenvalues.Random    <- matrix(0, nrow = 100, ncol = k)
    Random.Data           <- matrix(0, nrow = N,   ncol = k)
    for (i in 1:100) {
      for (j in 1:k) Random.Data[,j] <- sample(Distributions[,j], size = N, replace = TRUE)
      Eigenvalues.Random[i,] <- eigen(cor(Random.Data))$values }
    Eigenvalues.Random <- apply(Eigenvalues.Random, 2, mean)        # calculate mean eigenvalue for each factor     
    N.Factors <- max(1, sum(Eigenvalues.Observed > Eigenvalues.Random)) }
  ################################################################################################################
  # Generate random normal data for shared and unique components, initialize factor loadings (steps 5, 6) --------
  Shared.Comp <- matrix(rnorm(N*N.Factors, 0,1), nrow = N, ncol = N.Factors)
  Unique.Comp <- matrix(rnorm(N*k, 0,1), nrow = N, ncol = k)
  Shared.Load <- matrix(0, nrow =k, ncol = N.Factors)
  Unique.Load <- matrix(0, nrow =k, ncol = 1)
  ################################################################################################################
  # Begin loop that ends when specified number of iterations pass without improvement in RMSR correlation --------
  while (Trials.Without.Improvement < Max.Trials) {
    Iteration <- Iteration + 1
    ############################################################################################################
    # Calculate factor loadings and apply to reproduce desired correlations (steps 7, 8) -----------------------
    Fact.Anal <- Factor.Analysis(Intermediate.Corr, Corr.Matrix = TRUE, N.Factors = N.Factors)
    if (N.Factors == 1) Shared.Load[,1] <- Fact.Anal$loadings else 
      Shared.Load <- Fact.Anal$loadings
    Shared.Load[Shared.Load >  1] <-  1
    Shared.Load[Shared.Load < -1] <- -1
    if (Shared.Load[1,1] < 0) Shared.Load <- Shared.Load * -1
    Shared.Load.sq <- Shared.Load * Shared.Load
    for (i in 1:k)
      if (sum(Shared.Load.sq[i,]) < 1) Unique.Load[i,1] <- (1 - sum(Shared.Load.sq[i,])) else 
        Unique.Load[i,1] <- 0
    Unique.Load <- sqrt(Unique.Load)
    for (i in 1:k)
      Data[,i] <- (Shared.Comp %*% t(Shared.Load))[,i] + Unique.Comp[,i] * Unique.Load[i,1]
    # the %*% operator = matrix multiplication, and the t() function = transpose (both used again in step 13)   
    ############################################################################################################
    # Replace normal with non-normal distributions (step 9) ----------------------------------------------------
    for (i in 1:k) {
      Data <- Data[sort.list(Data[,i]),]
      Data[,i] <- Distributions[,i] }
    ############################################################################################################
    # Calculate RMSR correlation, compare to lowest value, take appropriate action (steps 10, 11, 12) ----------
    Reproduced.Corr <- cor(Data)
    Resid.Corr <- Target.Corr - Reproduced.Corr
    RMSR <- sqrt(sum(Resid.Corr[lower.tri(Resid.Corr)]*Resid.Corr[lower.tri(Resid.Corr)])/(0.5*(k*k-k)))
    if (RMSR < Best.RMSR) {
      Best.RMSR <- RMSR
      Best.Corr <- Intermediate.Corr
      Best.Res  <- Resid.Corr
      Intermediate.Corr <- Intermediate.Corr + Initial.Multiplier * Resid.Corr
      Trials.Without.Improvement <- 0 } else {
        Trials.Without.Improvement <- Trials.Without.Improvement + 1
        Current.Multiplier <- Initial.Multiplier * 0.5 ^ Trials.Without.Improvement
        Intermediate.Corr  <- Best.Corr + Current.Multiplier * Best.Res }
  } # end of the while loop
  ################################################################################################################
  # Construct the data set with the lowest RMSR correlation (step 13) --------------------------------------------
  Fact.Anal <- Factor.Analysis(Best.Corr, Corr.Matrix = TRUE, N.Factors = N.Factors)
  if (N.Factors == 1) Shared.Load[,1] <- Fact.Anal$loadings else 
    Shared.Load <- Fact.Anal$loadings
  Shared.Load[Shared.Load  > 1] <-  1
  Shared.Load[Shared.Load < -1] <- -1
  if (Shared.Load[1,1] < 0) Shared.Load <- Shared.Load * -1
  Shared.Load.sq <- Shared.Load * Shared.Load
  for (i in 1:k)
    if (sum(Shared.Load.sq[i,]) < 1) Unique.Load[i,1] <- (1 - sum(Shared.Load.sq[i,])) else 
      Unique.Load[i,1] <- 0
  Unique.Load <- sqrt(Unique.Load)
  for (i in 1:k)
    Data[,i] <- (Shared.Comp %*% t(Shared.Load))[,i] + Unique.Comp[,i] * Unique.Load[i,1]
  Data <- apply(Data, 2, scale)       # standardizes each variable in the matrix                                  
  for (i in 1:k) {
    Data <- Data[sort.list(Data[,i]),]
    Data[,i] <- Distributions[,i] }
  ################################################################################################################
  # Report the results and return the simulated data set (step 14) -----------------------------------------------
  Iteration <- Iteration - Max.Trials
  #cat("\nN =",N,", k =",k,",",Iteration,"Iterations,",N.Factors,"Factors, RMSR r =",round(Best.RMSR,3),"\n")
  return(Data) }

# Simulate multivariate non-normal data using GenData3 for binary confounding & binary outcome
GenData3 <- function(N, k, LPrev, YPrev, Data.Cor, N.Factors, Max.Trials=5, Initial.Multiplier=1, seed) {
  ################################################################################################################
  # Initialize variables and (if applicable) set random number seed (step 1) -------------------------------------
  # N             <- dim(Supplied.Data)[1]        # Number of cases                                                   
  # k             <- dim(Supplied.Data)[2]        # Number of variables                                               
  Data          <- matrix(0, nrow=N, ncol=k)    # Matrix to store the simulated data                                
  Distributions <- matrix(0, nrow=N, ncol=k)    # Matrix to store each variable's score distribution                
  Iteration     <- 0                            # Iteration counter                                                 
  Best.RMSR     <- 1                            # Lowest RMSR correlation                                           
  Trials.Without.Improvement <- 0               # Trial counter                                                     
  if (seed != 0) set.seed(seed)                 # If user specified a nonzero seed, set it                          
  ################################################################################################################
  # Generate distribution for each variable (step 2) -------------------------------------------------------------
  # for (i in 1:k) Distributions[,i] <- sort(sample(Supplied.Data[,i], N, replace = TRUE))
  Distributions[,1] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,2] <- sort(rbinom(N,1,LPrev))    # Binary distribution with p = LPrev                       
  Distributions[,3] <- sort(rnorm(N,0,1))         # Standard normal distribution                              
  Distributions[,4] <- sort(rnorm(N,0,1))         # Standard normal distribution                         
  Distributions[,5] <- sort(rbinom(N,1,YPrev))    # Binary distribution with p = YPrev                       
  # This implementation of GenData bootstraps each variable's score distribution from a supplied data set.        
  # Users should modify this block of the program, as needed, to generate the desired distribution(s).            
  ################################################################################################################
  # Calculate and store a copy of the target correlation matrix (step 3) -----------------------------------------
  # Target.Corr         <- cor(Supplied.Data)
  Target.Corr         <- Data.Cor
  Intermediate.Corr   <- Target.Corr
  # This implementation of GenData calculates the target correlation matrix from a supplied dataset.              
  # Alternatively, the user can modify the program to generate data with user-defined sample size, number of      
  # variables and target correlation matrix by redefining the function as follows:                                
  #   GenData <- function(N,k,Target.Corr,N.Factors=0,Max.Trials=5,Initial.Multiplier=1,seed=0)                   
  # In this case, one would also remove the program lines that calculate N, k, and Target.Corr.                   
  # To generate data in which variables are uncorrelated, one would remove the SsortT function from step 2        
  # and terminate the program before step 3 begins by returning the Distributions object as the dataset.          
  ################################################################################################################
  # If number of latent factors was not specified, determine it through parallel analysis (step 4) ---------------
  if (N.Factors == 0) {
    Eigenvalues.Observed  <- eigen(Intermediate.Corr)$values
    Eigenvalues.Random    <- matrix(0, nrow = 100, ncol = k)
    Random.Data           <- matrix(0, nrow = N,   ncol = k)
    for (i in 1:100) {
      for (j in 1:k) Random.Data[,j] <- sample(Distributions[,j], size = N, replace = TRUE)
      Eigenvalues.Random[i,] <- eigen(cor(Random.Data))$values }
    Eigenvalues.Random <- apply(Eigenvalues.Random, 2, mean)        # calculate mean eigenvalue for each factor     
    N.Factors <- max(1, sum(Eigenvalues.Observed > Eigenvalues.Random)) }
  ################################################################################################################
  # Generate random normal data for shared and unique components, initialize factor loadings (steps 5, 6) --------
  Shared.Comp <- matrix(rnorm(N*N.Factors, 0,1), nrow = N, ncol = N.Factors)
  Unique.Comp <- matrix(rnorm(N*k, 0,1), nrow = N, ncol = k)
  Shared.Load <- matrix(0, nrow =k, ncol = N.Factors)
  Unique.Load <- matrix(0, nrow =k, ncol = 1)
  ################################################################################################################
  # Begin loop that ends when specified number of iterations pass without improvement in RMSR correlation --------
  while (Trials.Without.Improvement < Max.Trials) {
    Iteration <- Iteration + 1
    ############################################################################################################
    # Calculate factor loadings and apply to reproduce desired correlations (steps 7, 8) -----------------------
    Fact.Anal <- Factor.Analysis(Intermediate.Corr, Corr.Matrix = TRUE, N.Factors = N.Factors)
    if (N.Factors == 1) Shared.Load[,1] <- Fact.Anal$loadings else 
      Shared.Load <- Fact.Anal$loadings
    Shared.Load[Shared.Load >  1] <-  1
    Shared.Load[Shared.Load < -1] <- -1
    if (Shared.Load[1,1] < 0) Shared.Load <- Shared.Load * -1
    Shared.Load.sq <- Shared.Load * Shared.Load
    for (i in 1:k)
      if (sum(Shared.Load.sq[i,]) < 1) Unique.Load[i,1] <- (1 - sum(Shared.Load.sq[i,])) else 
        Unique.Load[i,1] <- 0
    Unique.Load <- sqrt(Unique.Load)
    for (i in 1:k)
      Data[,i] <- (Shared.Comp %*% t(Shared.Load))[,i] + Unique.Comp[,i] * Unique.Load[i,1]
    # the %*% operator = matrix multiplication, and the t() function = transpose (both used again in step 13)   
    ############################################################################################################
    # Replace normal with non-normal distributions (step 9) ----------------------------------------------------
    for (i in 1:k) {
      Data <- Data[sort.list(Data[,i]),]
      Data[,i] <- Distributions[,i] }
    ############################################################################################################
    # Calculate RMSR correlation, compare to lowest value, take appropriate action (steps 10, 11, 12) ----------
    Reproduced.Corr <- cor(Data)
    Resid.Corr <- Target.Corr - Reproduced.Corr
    RMSR <- sqrt(sum(Resid.Corr[lower.tri(Resid.Corr)]*Resid.Corr[lower.tri(Resid.Corr)])/(0.5*(k*k-k)))
    if (RMSR < Best.RMSR) {
      Best.RMSR <- RMSR
      Best.Corr <- Intermediate.Corr
      Best.Res  <- Resid.Corr
      Intermediate.Corr <- Intermediate.Corr + Initial.Multiplier * Resid.Corr
      Trials.Without.Improvement <- 0 } else {
        Trials.Without.Improvement <- Trials.Without.Improvement + 1
        Current.Multiplier <- Initial.Multiplier * 0.5 ^ Trials.Without.Improvement
        Intermediate.Corr  <- Best.Corr + Current.Multiplier * Best.Res }
  } # end of the while loop
  ################################################################################################################
  # Construct the data set with the lowest RMSR correlation (step 13) --------------------------------------------
  Fact.Anal <- Factor.Analysis(Best.Corr, Corr.Matrix = TRUE, N.Factors = N.Factors)
  if (N.Factors == 1) Shared.Load[,1] <- Fact.Anal$loadings else 
    Shared.Load <- Fact.Anal$loadings
  Shared.Load[Shared.Load  > 1] <-  1
  Shared.Load[Shared.Load < -1] <- -1
  if (Shared.Load[1,1] < 0) Shared.Load <- Shared.Load * -1
  Shared.Load.sq <- Shared.Load * Shared.Load
  for (i in 1:k)
    if (sum(Shared.Load.sq[i,]) < 1) Unique.Load[i,1] <- (1 - sum(Shared.Load.sq[i,])) else 
      Unique.Load[i,1] <- 0
  Unique.Load <- sqrt(Unique.Load)
  for (i in 1:k)
    Data[,i] <- (Shared.Comp %*% t(Shared.Load))[,i] + Unique.Comp[,i] * Unique.Load[i,1]
  Data <- apply(Data, 2, scale)       # standardizes each variable in the matrix                                  
  for (i in 1:k) {
    Data <- Data[sort.list(Data[,i]),]
    Data[,i] <- Distributions[,i] }
  ################################################################################################################
  # Report the results and return the simulated data set (step 14) -----------------------------------------------
  Iteration <- Iteration - Max.Trials
  #cat("\nN =",N,", k =",k,",",Iteration,"Iterations,",N.Factors,"Factors, RMSR r =",round(Best.RMSR,3),"\n")
  return(Data) }

# Routine used by GenData
Factor.Analysis <- function(Data, Corr.Matrix=FALSE, Max.Iter=50, N.Factors=0) {
  Data <- as.matrix(Data)
  k    <- dim(Data)[2]
  if (N.Factors == 0) N.Factors <- k
  if (!Corr.Matrix) Cor.Matrix <- cor(Data) else 
    Cor.Matrix <- Data
  Criterion <- .001
  Old.H2 <- rep(99, k)
  H2 <- rep(0, k)
  Change <- 1
  Iter <- 0
  Factor.Loadings <- matrix(nrow = k, ncol = N.Factors)
  while ((Change >= Criterion) & (Iter < Max.Iter)) {
    Iter <- Iter + 1
    Eig <- eigen(Cor.Matrix)
    L <- sqrt(Eig$values[1:N.Factors])
    for (i in 1:N.Factors)
      Factor.Loadings[,i] <- Eig$vectors[,i] * L[i]
    for (i in 1:k)
      H2[i] <- sum(Factor.Loadings[i,] * Factor.Loadings[i,])
    Change <- max(abs(Old.H2 - H2))
    Old.H2 <- H2
    diag(Cor.Matrix) <- H2 }
  if (N.Factors == k) N.Factors <- sum(Eig$values > 1)
  return(list(loadings = Factor.Loadings[,1:N.Factors], factors = N.Factors)) }

# Find optimal number of latent factors to use in GenData
Optimise_N.Factors <- function (dag, nReps, Prev) {
  Eval    <- Opt <- NULL
  Cor     <- Reorder_Mat(round(cor(simulateSEM(dag, b.default = 0, N = nPop, empirical = TRUE)),3), vOrder)
  Target  <- Cor[lower.tri(Cor)]
  clusterExport(cl, c("Cor", "nReps", "Prev", "Target"))
  for (nF in 1:4) {
    print(paste0("Setting ", nF))
    Start <- Sys.time()
    Miss  <- Ymiss <- NULL
    missy <- parLapply(cl, 1:nReps, function(itn) {
      seed          <- 17 * nReps * itn
      MyData        <- data.frame(GenData(N = nPop, k = 5, Prev = Prev, Data.Cor = Cor, 
                                          N.Factors = nF, Max.Trials = 5, Initial.Multiplier = 1, seed = seed))
      names(MyData) <- vOrder
      MyData        <- tibble(MyData)
      MyCor         <- cor(MyData)
      Shot          <- MyCor[lower.tri(MyCor)]
      data.frame(Miss = sqrt(sum((Target - Shot)^2)), Ymiss = sqrt(sum((Target[c(4,7,9,10)]-Shot[c(4,7,9,10)])^2))) } )
    Miss  <- c(Miss,  missy[1])
    Ymiss <- c(Ymiss, missy[2])
    Time  <- Sys.time() - Start; print(Time)
    Opt   <- rbind(Opt, data.frame(nF = nF, Bias = median(Miss), Ybias = median(Ymiss), Spread = 2*sd(Miss), Time = Time)) }
  return(Opt) }

# Tuning of the GenData algorithm to determine optimal number of factors (nF)
GetOptnF  <- function(iLoop, jLoop, GenSub) {
  Start   <- Sys.time()                                                         # time execution
  Opt.Out <- list()                                                             # store optimal results
  for (iConf in iLoop) {                                                        # cycle through scenarios
    print(paste0("Tuning scenario ", iConf))                                    # signpost progress
    Out      <- NULL                                                            # store loop optimisation results
    for (jPath in jLoop) {                                                      # cycle through effect sizes
      print(paste0("Effect Size ", jPath))                                      # signpost progress
      dag    <- DAG_ZLNXY(paths = Paths[[iConf]][which(pX_Y %in% jPath),])      # get the regular DAG
      MVCor  <- Reorder_Mat(round(cor(simulateSEM(dag, b.default = 0, N = nPop, # get exact target MV normal data
                                                  empirical = TRUE)),3), vOrder)# & extract its correlation matrix
      Target <- MVCor[lower.tri(MVCor)]                                         # examine lower triangle 
      for (nF in 1:4) {                                                         # try all numbers of latent factors
        nFtime  <- Sys.time()                                                   # time the loop execution
        Miss    <- Ymiss <- NULL                                                # storage for deviations from target
        iConf   <<- iConf; jPath  <<- jPath; nF <<- nF; GenSub <<- GenSub       # hack the global environment issue
        MVCor   <<- MVCor; Target <<- Target
        clusterExport(cl, c("jPath", "nF", "GenSub", "MVCor", "Target",         # export what's needed by clusters
                            "OptN", "YPrev", "LPrev"))
        missy   <- parLapply(cl, 1:OptN, function(itn) {                        # loop through replications
          Status  <- TRUE                                                       # Boolean for tryCatch
          seed    <- 3 * jPath * nF * itn                                       # set independent seed
          if (GenSub == 1) {                                                    # - binary outcome low prevalence
            Data <- tryCatch(GenData1(N = nPop, k = 5, Prev = YPrev,            # use tryCatch for failed simulations
                                      seed = seed, Data.Cor = MVCor, 
                                      N.Factors = nF,Max.Trials = 5, 
                                      Initial.Multiplier = 1),
                             error = function(e) { TRUE }, warning = function(w) { TRUE }) }
          if (GenSub == 2) {                                                    # binary L-confounding, continuous outcome
            Data <- tryCatch(GenData2(N = nPop, k = 5, Prev = LPrev, 
                                      seed = seed, Data.Cor = MVCor, 
                                      N.Factors = nF, Max.Trials = 5, 
                                      Initial.Multiplier = 1),
                             error = function(e) { TRUE }, warning = function(w) { TRUE }) }
          if (GenSub == 3) {                                                    # binary L-confounding, binary outcome
            Data <- tryCatch(GenData3(N = nPop, k = 5, LPrev = LPrev, 
                                      YPrev = YPrev, seed = seed, 
                                      Data.Cor = MVCor, N.Factors = nF, 
                                      Max.Trials = 5, Initial.Multiplier = 1),
                             error = function(e) { TRUE }, warning = function(w) { TRUE }) }
          if ("logical" %in% class(Data)) { Status <- FALSE                     # flag failures to be assigned NAs
          } else { Data <- data.frame(Data); names(Data) <- vOrder }            # order the output data correctly
          if (Status == TRUE) { 
            MyCor <- cor(Data)                                                  # get GenData correlation matrix
            Shot  <- MyCor[lower.tri(MyCor)]                                    # get its lower triangle 
            data.table(Miss  = sqrt(sum((Target - Shot)^2)),                    # cf dagitty MV normal correlations with
                       Ymiss = sqrt(sum((Target[c(4,7,9,10)] -                  # GenData MV non-normal correlations
                                           Shot[c(4,7,9,10)])^2)), Status = TRUE) 
          } else { data.table(Miss = 99, Ymiss = 99, Status = FALSE) } } )      # assign NAs where failed
        Time    <- Sys.time() - nFtime; print(Time)                             # get time for nF value used
        missy   <- do.call(rbind, missy)                                        # collate into large file
        nFail   <- sum(missy$Status == FALSE)                                   # count number of failed simulations
        missy   <- missy[missy$Status == TRUE,]                                 # drop failed simulations
        Miss    <- as.numeric(unlist(missy[,1]))                                # discrepancies over all correlations
        Ymiss   <- as.numeric(unlist(missy[,2]))                                # discrepancies for Y-based correlations
        if (nFail == OptN) { Bias <- Ybias <- Spread <- 99                      # to accommodate total failure
        } else { 
          Bias   <- median(Miss)                                                # as a median summary over OptN runs
          Ybias  <- median(Ymiss)
          Spread <- 2*sd(Miss) }                                                # Note: GenData has no 'empirical = TRUE'
        Out     <- rbind(Out, data.frame(Conf = iConf, pX_Y = jPath, nF = nF,   # store tuning/performance findings 
                                         nFail = nFail, Bias = Bias, 
                                         Ybias = Ybias, Spread = Spread, 
                                         Time = Time)) } }
    Opt.Out[[iConf]] <- Out }                                                   # store summary findings
  print(Sys.time() - Start)
  Metrics <<- do.call(rbind, Opt.Out)
  Opt     <- NULL                                                               # augmented optimisation statistics
  for (iConf in iLoop) {                                                        # loop through scenarios
    for (jPath in pX_Y) {                                                       # loop through path coefficients
      Set       <- Metrics[(Metrics$Conf == iConf) &                            # select optimised values
                             (round(Metrics$pX_Y,2) == round(jPath,2)),]
      Set$Time  <- as.numeric(Set$Time)                                         # convert time to numeric
      Include   <- Set[Set$Spread != 99 & !is.na(Set$Spread),]$nF               # non-missing data
      SubSet    <- Set[Set$nF %in% Include, -c(1:2,4)]                          # select non-missing data
      Minimum   <- apply(SubSet[,-1], 2, min)                                   # extract minimal column values
      Rate      <- data.frame(nF = Include,                                     # generate relative measures
                              do.call(rbind, lapply(Include, \(iInc) { SubSet[SubSet$nF == iInc,-1]/Minimum })))
      names(Rate) <- c("nF", "dB", "dY", "dSD", "dT")                           # label new optimisation statistics
      AddMiss   <- setdiff(1:4, Include) 
      if (NROW(AddMiss) > 0) {                                                  # add NAs if necessary
        for (itn in AddMiss) Rate <- rbind(Rate, data.frame(nF = itn, dB = 99, dY = 99, dSD = 99, dT = 99)) }
      ThisRun   <- left_join(Set, Rate, by = "nF")                              # generate updated optimisation data
      Opt       <- bind_rows(Opt, ThisRun) } }                                  # stack results
  Opt$RelBias   <- Opt$Bias/min(Opt$Bias)                                       # gradient biases across all options
  if (sum(Opt$dB == 99) > 0) Opt[Opt$dB == 99,]$RelBias <- NA
  write.table(Opt, file = FileName, sep = ",", row.names = FALSE)
  return(Opt) }

## FUNCTIONS  - DAG GENERATION ROUTINES ----------------------------------------
# Create a dag
DAG_ZLNXY <- function(paths) {
  p       <- paths
  dag     <- dagitty(paste0("dag{ Z->L [beta=",p[1],"] Z->N [beta=",p[2],"] Z->X [beta=",p[3],"] 
                                  Z->Y [beta=",p[4],"] L->N [beta=",p[5],"] L->X [beta=",p[6],"]
                                  L->Y [beta=",p[7],"] N->X [beta=",p[8],"] N->Y [beta=",p[9],"] 
                                  X->Y [beta=",p[10],"] }")); return(dag) }

# Path scenarios
path_configs <- function(config) {
# config 1: Z confounding of X & Y
# config 2: L confounding of X & Y
# config 3: Z & L confounding of X & Y
# config 4: Z & L confounding of X & Y with Z confounding L
  if        (config == 1) { return(c(pZ_L = 0,   pZ_N = 0, pZ_X = 0.3, pZ_Y = 0.3, pL_N = 0,   pL_X = 0,   pL_Y = 0,   pN_X = 0, pN_Y = 0))
  } else if (config == 2) { return(c(pZ_L = 0,   pZ_N = 0, pZ_X = 0,   pZ_Y = 0,   pL_N = 0.8, pL_X = 0.3, pL_Y = 0.3, pN_X = 0, pN_Y = 0))
  } else if (config == 3) { return(c(pZ_L = 0,   pZ_N = 0, pZ_X = 0.3, pZ_Y = 0.3, pL_N = 0.8, pL_X = 0.3, pL_Y = 0.3, pN_X = 0, pN_Y = 0))
  } else if (config == 4) { return(c(pZ_L = 0.8, pZ_N = 0, pZ_X = 0.3, pZ_Y = 0.3, pL_N = 0.8, pL_X = 0.3, pL_Y = 0.3, pN_X = 0, pN_Y = 0)) } } 

# Setup path coefficients
SetPaths <- function() {
  pX_Y  <<- seq(0.0, 0.5, by=0.1)
  Paths <<- vector(mode = "list", length = 4) 
  for (p in Configs) {
    Path <- c(path_configs(p), pX_Y = 0)
    for (j in 2:length(pX_Y)) { 
      Path <- rbind(Path, c(path_configs(p), pX_Y[j]))
      Paths[[p]] <<- Path } } 
}; SetPaths()

## FUNCTIONS  - MODELLING ROUTINES ---------------------------------------------
# Manipulate & aggregate data
AggData       <- function(data, type) {
  data        <- data.table(arrange(data, N))                                   # order with respect to N (ascending)
  data$N      <- round(data$N*sqrt(Nvar) + ClustSize)                           # scale-up to true mean/sd for aggregation
  N_agg       <- round(sapply(split(data$N, rep(1:nClust, each = ClustSize)),   # split into N_clust groups & sample N values
                                    function(x){sample(x, 1, replace = TRUE)})) # alternatively, N_agg = mean per cluster
  while (sum(N_agg) != nPop) {                                                  # manipulate N_agg to match population size
    diff      <- nPop - sum(N_agg)                                              # calculate discrepancy
    extra     <- rep(sign(diff), abs(diff))                                     # add 1's or -1's
    if (abs(diff) <= nClust) {                                                  # check discrepancy is smaller than nClust
      N_agg   <- N_agg + sample(c(extra, rep(0, length(N_agg)-abs(diff))))      # mix up with zeros for remainder
    } else { 
      Extra   <- split(extra, ceiling(seq_along(extra)/nClust))                 # if discrepancy is greater than nClust
      N_agg   <- rowSums(cbind(N_agg, sapply(1:length(Extra), function(x) {     # split up and apply multiple times
        sample(c(Extra[[x]], rep(0,length(N_agg)-length(Extra[[x]])))) } ))) }}
  data$cID    <- rep(1:nClust, N_agg)                                           # assign cluster ID to lower-level data
  agg_data    <- data                                                           # generate cluster aggregate data
  if (type=="CC") agg_data <- agg_data |> group_by(cID) |>                      # for the continuous outcome: means
    summarise(mZ=mean(Z), mL=mean(L), mN=mean(N), mX=mean(X), mY=mean(Y))       # throughout for all aggregates
  if (type=="CB") agg_data <- agg_data |> group_by(cID) |>                      # for the binary outcome: counts &
    summarise(mZ=mean(Z), mL=mean(L), mN=mean(N), mX=mean(X), mY=sum(Y))        # means for all other aggregates 
  if (type=="BC") agg_data <- agg_data |> group_by(cID) |>                      # for the binary confounder: counts &
    summarise(mZ=mean(Z), mL=sum(L),  mN=mean(N), mX=mean(X), mY=mean(Y))       # means for all other aggregates 
  if (type=="BB") agg_data <- agg_data |> group_by(cID) |>                      # for the binary confounder & binary outcome: 
    summarise(mZ=mean(Z), mL=sum(L),  mN=mean(N), mX=mean(X), mY=sum(Y))        # counts & means for all other aggregates 
  agg_data$mN <- N_agg                                                          # allocate correct cluster size
  return(list(data, agg_data)) } 

# multilevel estimates
MLmods <- function(MLD, Typ, Ztrue) {
  if (Typ == "C") {
    if (Ztrue) {
      MLX <- suppressMessages(lmer(Y ~ X + Z + N  + (1|cID), data = MLD))       # adjusted for obs L1 confounding & N 
    } else {
      MLX <- suppressMessages(lmer(Y ~ X     + N  + (1|cID), data = MLD)) }     # adjusted for N only
  } else {
    if (Ztrue) {
      MLX <- suppressMessages(glmer(Y ~ X + Z + N  + (1|cID), poisson, data = MLD))
    } else {
      MLX <- suppressMessages(glmer(Y ~ X     + N  + (1|cID), poisson, data = MLD)) 
    } }
  if (isSingular(MLX)) NS <- "NS" else NS <- "OK"                               # flag which ML models are near singular
  MLX <- summary(MLX)$coefficients[2,1]                                         # proxy ML estimate of X-Y causal effect
  return(data.frame(MLX = MLX, NS = NS)) }

# all models for continuous outcome
GetAllConEst <- function(L2data, Ztrue) {
  if (Ztrue) { cm2 <- coefficients(lm(mY  ~ mX +    mN + mZ, data = L2data))[2]
  } else     { cm2 <- coefficients(lm(mY  ~ mX +    mN,      data = L2data))[2] }
  if (Ztrue) { cm3 <- coefficients(lm(mY  ~ mX +  1/mN + mZ, data = L2data))[2]
  } else     { cm3 <- coefficients(lm(mY  ~ mX +  1/mN,      data = L2data))[2] }
  if (Ztrue) { cm4 <- coefficients(lm(rYN ~ rXN        + mZ, data = L2data))[2]
  } else     { cm4 <- coefficients(lm(rYN ~ rXN,             data = L2data))[2] }
  if (Ztrue) { cm5 <- coefficients(lm(rYN ~ rXN +   mN + mZ, data = L2data))[2]
  } else     { cm5 <- coefficients(lm(rYN ~ rXN +   mN,      data = L2data))[2] }
  if (Ztrue) { cm6 <- coefficients(lm(rYN ~ rXN + 1/mN + mZ, data = L2data))[2]
  } else     { cm6 <- coefficients(lm(rYN ~ rXN + 1/mN,      data = L2data))[2] }
  CM     <- data.frame(XZN = cm2, XZiN = cm3, rXZ = cm4, rXZN = cm5, rXZiN = cm6)
  return(CM) }

# all models for binary outcome
GetAllBinEst <- function(L2data, Ztrue) {
  if (Ztrue) { bm2 <- coefficients(glm(mY ~ mX  +   mN + mZ, data = L2data, family = poisson(link = "log")))[2]
  } else     { bm2 <- coefficients(glm(mY ~ mX  +   mN,      data = L2data, family = poisson(link = "log")))[2] }
  if (Ztrue) { bm3 <- coefficients(glm(mY ~ mX  + 1/mN + mZ, data = L2data, family = poisson(link = "log")))[2]
  } else     { bm3 <- coefficients(glm(mY ~ mX  + 1/mN,      data = L2data, family = poisson(link = "log")))[2] }
  if (Ztrue) { bm4 <- coefficients(lm(rYN ~ rXN +        mZ, data = L2data))[2]
  } else     { bm4 <- coefficients(lm(rYN ~ rXN,             data = L2data))[2] }
  if (Ztrue) { bm5 <- coefficients(lm(rYN ~ rXN +   mN + mZ, data = L2data))[2]
  } else     { bm5 <- coefficients(lm(rYN ~ rXN +   mN,      data = L2data))[2] }
  if (Ztrue) { bm6 <- coefficients(lm(rYN ~ rXN + 1/mN + mZ, data = L2data))[2]
  } else     { bm6 <- coefficients(lm(rYN ~ rXN + 1/mN,      data = L2data))[2] }
  if (Ztrue) { bm7 <- coefficients(glm(mY ~ mX  +        mZ, offset = log(mN), data = L2data, family = poisson(link = "log")))[2]
  } else     { bm7 <- coefficients(glm(mY ~ mX,              offset = log(mN), data = L2data, family = poisson(link = "log")))[2] }
  BM     <- data.frame(XZN = bm2, XZiN = bm3, rXZ = bm4, rXZN = bm5, rXZiN = bm6, XZoffN = bm7)
  return(BM) }

# minimal models for binary outcome
GetMinBinEst <- function(L2data, Ztrue) {
  if (Ztrue) { bm2 <- coefficients(glm(mY ~ mX  +   mN + mZ, data = L2data, family = poisson(link = "log")))[2]
  } else     { bm2 <- coefficients(glm(mY ~ mX  +   mN,      data = L2data, family = poisson(link = "log")))[2] }
  BM     <- data.frame(XZN = bm2, rXZiN <- NA) # for data frame to be correctly orientated later
  return(BM) }

# minimal models for continuous outcome
GetMinConEst <- function(L2data, Ztrue) {
  if (Ztrue) { cm2 <- coefficients(lm(mY  ~ mX +    mN + mZ, data = L2data))[2]
  } else     { cm2 <- coefficients(lm(mY  ~ mX +    mN,      data = L2data))[2] }
  CM     <- data.frame(XZN = cm2, rXZiN = NA)
  return(CM) }

## FUNCTIONS  - MAIN SIMULATION ROUTINE ----------------------------------------
# model binary/cont outcomes & binary/cont confounding with true estimates
GetEstimates <- function(iLoop, jLoop, Optimal, Option) {
  if (Option == "N") GenSub <- 0                                                # continuous outcome continuous confounder
  if (Option == "Y") GenSub <- 1                                                # binary outcome 0.1 prev continuous confounder
  if (Option == "R") GenSub <- 2                                                # binary outcome 0.001 prev continuous confounder
  if (Option == "L") GenSub <- 3                                                # continuous outcome binary confounder
  if (Option == "B") GenSub <- 4                                                # both binary outcome binary confounder
  Est   <- NULL                                                                 # storage of all the results in one place
  Start <- Sys.time()                                                           # record total execution time
  for (iConf in iLoop) {                                                        # loop through scenarios
    ConfTime  <- Sys.time()                                                     # loop execution time
    for(jPath in jLoop) {                                                       # loop through X-Y path coefficients
      PathTime  <- Sys.time()                                                   # loop execution time
      jIndex    <- which(round(pX_Y,2) %in% round(jPath,2))                     # index path coefficient
      print(paste0("Scenario ",iConf," - Effect-Size ",jPath))                  # signpost progress
      if (class(Optimal) %in% "data.frame") {                                   # only relevant for non-normal variables
        match   <- Optimal$Conf==iConf & round(Optimal$pX_Y,2)==round(jPath,2)
        nF      <- Optimal[match, ]$n 
        } else { nF <- 0 } 
      dag       <- DAG_ZLNXY(paths = Paths[[iConf]][jIndex,])                   # get the DAG
      Cor       <- Reorder_Mat(impliedCovarianceMatrix(dag), vOrder)            # get implied correlation matrix
      Sigma     <- cor2cov(Cor, as.numeric(sqrt(var)))                          # make into covariance matrix
      for (kSeg in 1:nSeg) {                                                    # break the nSims loop into nSeg segments
        iConf <<- iConf; jPath <<- jPath; jIndex <<- jIndex; kSeg <<- kSeg      # hack the global environment issue 
        Sigma <<- Sigma; Paths <<- Paths; Cor    <<- Cor;    nF   <<- nF 
        YPrev <<- YPrev; LPrev <<- LPrev; GenSub <<- GenSub
        clusterExport(cl, c("iConf", "jPath", "jIndex", "kSeg", "Sigma",        # export required entities to clusters
                            "Paths", "Cor", "nF", "YPrev", "LPrev", "GenSub"))
        Segment   <- parLapply(cl, 1:(nSims/nSeg), function(lSim) {             # loop through segment replications
          Status  <- TRUE
          if (GenSub == 0 ) { set.seed(3 * iConf * jIndex * kSeg * lSim)        # set seed for each repeated simulation
          } else { seed <- 3 * iConf * jIndex * kSeg * lSim }
          if (GenSub == 0) {
            SimData <- data.table(mvrnorm(nPop,Means,Sigma)) }                  # simulate MV normal dataset
          if (GenSub == 1 | GenSub == 2) {                                      # binary outcome continuous confounding
            SimData <- tryCatch(GenData1(N = nPop, k = 5, N.Factors = nF, 
                                         Prev = YPrev, Data.Cor = Cor, seed = seed),
                                error = function(e) { TRUE }, warning = function(w) { TRUE }) }
          if (GenSub == 3) {                                                    # continuous outcome binary confounding
            SimData <- tryCatch(GenData2(N = nPop, k = 5, N.Factors = nF, 
                                         Prev = LPrev, Data.Cor = Cor, seed = seed),
                                error = function(e) { TRUE }, warning = function(w) { TRUE }) }
          if (GenSub == 4) {                                                    # binary outcome binary confounding
            SimData <- tryCatch(GenData3(N = nPop, k = 5, N.Factors = nF, LPrev = LPrev, 
                                         YPrev = YPrev, Data.Cor = Cor, seed = seed),
                                error = function(e) { TRUE }, warning = function(w) { TRUE }) }
          if ("logical" %in% class(SimData)) { Status <- FALSE                  # check if GenData converged
          } else { SimData <- as.data.table(SimData); names(SimData) <- vOrder} # make data table & order variables
          if (Status == TRUE) {
            if (GenSub == 0)               New  <- AggData(SimData, "CC")       # aggregate data
            if (GenSub == 1 | GenSub == 2) New  <- AggData(SimData, "CB")
            if (GenSub == 3)               New  <- AggData(SimData, "BC")
            if (GenSub == 4)               New  <- AggData(SimData, "BB")  
            Ztrue   <- Paths[[iConf]][jIndex, "pZ_X"] == 0.3                    # Z-confounding or not?
            L2D     <- data.frame(Conf = iConf, pX_Y = jPath, New[[2]])         # upper-level dataset
            L2D     <- dplyr::select(L2D, Conf, pX_Y, mY, mX, mZ, mL, mN, cID)  # select variables needed
            L2D$rXN <- L2D$mX/L2D$mN                                            # create X/N ecological ratio exposure variable
            L2D$rYN <- L2D$mY/L2D$mN                                            # create Y/N ecological ratio outcome variable
            if (GenSub == 0)               EcolEst <- GetAllConEst(L2D, Ztrue)  # get ecological model coefficients
            if (GenSub == 1)               EcolEst <- GetAllBinEst(L2D, Ztrue)
            if (GenSub == 2 | GenSub == 4) EcolEst <- GetMinBinEst(L2D, Ztrue)
            if (GenSub == 3)               EcolEst <- GetMinConEst(L2D, Ztrue)
            MLData  <- data.frame(Conf = iConf, pX_Y = jPath,                   # create multilevel dataset
                                  left_join(New[[1]], New[[2]], by = "cID"))
            MLData  <- dplyr::select(MLData, Conf, pX_Y, Y, X, Z, L, N, mY,     # select variables needed
                                     mX, mZ, mL, mN, cID)
            if (GenSub %in% c(0, 3)) {
              if (Ztrue) {
                SLX <- coefficients(lm(Y ~ X + Z + L, data = MLData))[2]        # fully adjusted SL model X-coeff - 'true'
                MLX <- lmer(Y ~ X + Z + L + (1|cID),  data = MLData)            # fully adjusted ML model X-coeff - 'true'
                MLX <- summary(MLX)$coefficients[2,1]
              } else {
                SLX <- coefficients(lm(Y ~ X + L, data = MLData))[2]
                MLX <- lmer(Y ~ X + L + (1|cID),  data = MLData)
                MLX <- summary(MLX)$coefficients[2,1] } }
            if (GenSub %in% c(1, 2, 4)) {                                       # check if GLMS converged
              if (Ztrue) {
                TryMod <- tryCatch(glm(Y ~ X + Z + L, data = MLData, family = poisson),
                                   error = function(e) { TRUE }, warning = function(w) { TRUE })
                if ("logical" %in% class(TryMod)) { 
                  SLX <- NA
                  print("Failed SLX: iConf, jPath, kSeg, lSim ...")
                  print(c(iConf, jPath, kSeg, lSim)) 
                } else { SLX <- coefficients(TryMod)[2] }
                TryMod <- tryCatch(glmer(Y ~ X + Z + L + (1|cID),  data = MLData, family = poisson),
                                   error = function(e) { TRUE }, warning = function(w) { TRUE })
                if ("logical" %in% class(TryMod)) {
                  MLX <- NA
                  print("Failed MLX: iConf, jPath, kSeg, lSim ...")
                  print(c(iConf, jPath, kSeg, lSim)) 
                } else { MLX <- summary(TryMod)$coefficients[2,1] }
              } else {
                TryMod <- tryCatch(glm(Y ~ X + L, data = MLData, family = poisson),
                                   error = function(e) { TRUE }, warning = function(w) { TRUE })
                if ("logical" %in% class(TryMod)) { 
                  SLX <- NA
                  print("Failed SLX: iConf, jPath, kSeg, lSim ...")
                  print(c(iConf, jPath, kSeg, lSim)) 
                } else { SLX <- coefficients(TryMod)[2] }
                TryMod <- tryCatch(glmer(Y ~ X + L + (1|cID),  data = MLData, family = poisson),
                                   error = function(e) { TRUE }, warning = function(w) { TRUE })
                if ("logical" %in% class(TryMod)) {
                  MLX <- NA
                  print("Failed MLX: iConf, jPath, kSeg, lSim ...")
                  print(c(iConf, jPath, kSeg, lSim)) 
                } else { MLX <- summary(TryMod)$coefficients[2,1] } } }
            if (GenSub %in% c(0, 3))    ML <- MLmods(MLData, "C", Ztrue)        # ML models X-coefficients
            if (GenSub %in% c(1, 2, 4)) ML <- MLmods(MLData, "B", Ztrue)
            data.table(Conf = iConf, pX_Y = jPath, MLtrue = MLX, SLtrue = SLX,  # combine true ML, true SL, Ecol, & ML results
                       EcolEst, ML) } } )                                       # including ML performance indicator
        SegEst  <- do.call(rbind, Segment)                                      # collate segmented results
        Est     <- rbind(Est, SegEst); TempEst <<- Est }                        # collate all repeats with backup for crashes
      print(Sys.time() - PathTime) }                                            # signpost progress
    print(Sys.time() - ConfTime) }; print(Sys.time() - Start)                   # config time & total time
  return(Est) }

## FUNCTIONS  - GRAPHICAL ROUTINES ---------------------------------------------
# Plots of multilevel & main ecological estimates for main scenarios for continuous outcome
CpltTxt1 <- function(modC, Text){
  modC <- modC[modC$Group %in% c("MLX", "XZN"),]                                # select data
  Cols <- Colors[1:2]                                                           # colours to use
  Lim  <- c(-0.005, 0.505, min(-0.005, modC$Y), max(modC$Y) + 0.005)            # plot bounds
  p <- ggplot(modC, aes(x = pX_Y, y = Y)) + theme_classic() +
    geom_jitter(aes(colour = Group), size = 4, shape = 18, 
                position = position_jitter(width = 0.003, height = 0.003, seed = 13)) +
    geom_smooth(aes(colour = Group), linewidth = 1, method = 'lm', 
                formula = y ~ poly(x,2), se = FALSE, alpha = 0.1, 
                position = position_jitterdodge(dodge.width = 0.001)) + 
    geom_abline(intercept = 0, slope = 1, color = "grey", 
                linetype = "dashed", linewidth = 1) + xlab(XlabC) + ylab(Ylab) + 
    xlim(Lim[1], Lim[2]) + ylim(Lim[3], Lim[4]) + 
    annotate(geom = "text", x = 0, y = Lim[4] - 0.02, label = Text, 
             size = 16, color="black") +
    theme(axis.text.x  = element_text(size = 22, face = "bold", colour = "black"),
          axis.text.y  = element_text(size = 22, face = "bold", colour = "black"), 
          axis.title.x = element_text(size = 24, face = "bold"),
          axis.title.y = element_text(size = 24, face = "bold"),
          legend.position = "top", legend.justification = "left",
          legend.text  = element_text(size = 28, face = "bold"), 
          legend.title = element_blank() ) +
    guides(colour = guide_legend(nrow = 1)) +
    scale_color_manual(values = Cols, labels = LabelsC[1:2])
  return(p) }

# Plots of multilevel & main ecological estimates for main scenarios for binary outcome
BpltTxt1 <- function(modB, Text){
  modB <- modB[modB$Group %in% c("MLX", "XZN"),]
  Cols <- Colors[1:2]
  Lim  <- c(-0.02, max(modB$X) + 0.05, min(-0.02, modB$Y), max(modB$Y) + 0.05)
  p <- ggplot(modB, aes(x = X, y = Y)) + theme_classic() +
    geom_jitter(aes(colour = Group), size = 4, shape = 18, 
                position = position_jitter(width = 0.003, height = 0.003, seed = 13)) +
    geom_smooth(aes(colour = Group), linewidth = 1, method = 'lm', 
                formula = y ~ poly(x,2), se = FALSE, alpha = 0.1, 
                position = position_jitterdodge(dodge.width = 0.001)) + 
    geom_abline(intercept = 0, slope = 1, color = "grey", 
                linetype = "dashed", linewidth = 1) + xlab(XlabB) + ylab(Ylab) +
    xlim(Lim[1], Lim[2]) + ylim(Lim[3], Lim[4]) + 
    annotate(geom = "text", x = 0, y = Lim[4] - 0.02, label = Text, 
             size = 16, color="black") +
    theme(axis.text.x  = element_text(size = 22, face = "bold", colour = "black"),
          axis.text.y  = element_text(size = 22, face = "bold", colour = "black"), 
          axis.title.x = element_text(size = 24, face = "bold"),
          axis.title.y = element_text(size = 24, face = "bold"),
          legend.position = "top", legend.justification = "left",
          legend.text  = element_text(size = 28, face = "bold"), 
          legend.title = element_blank() ) +
    guides(colour = guide_legend(nrow = 1)) +
    scale_color_manual(values = Cols, labels = LabelsB[1:2])
  return(p) }

# Plots of multilevel & remaining ecological estimates for main scenarios for continuous outcome
CpltApp1 <- function(modC, Text){
  modC <- modC[modC$Group != "XZN",]
  Cols <- Colors[-c(2,7)]
  Lim  <- c(-0.005, 0.505, min(-0.005, modC$Y), max(modC$Y) + 0.005)
  p <- ggplot(modC, aes(x = pX_Y, y = Y)) + theme_classic() +
    geom_jitter(aes(colour = Group), size = 4, shape = 18, 
                position = position_jitter(width = 0.003, height = 0.003, seed = 13)) +
    geom_smooth(aes(colour = Group), linewidth = 1, method = 'lm', 
                formula = y ~ poly(x,2), se = FALSE, alpha = 0.1, 
                position = position_jitterdodge(dodge.width = 0.001)) + 
    geom_abline(intercept = 0, slope = 1, color = "grey", 
                linetype = "dashed", linewidth = 1) + xlab(XlabC) + ylab(Ylab) + 
    xlim(Lim[1], Lim[2]) + ylim(Lim[3], Lim[4]) + 
    annotate(geom = "text", x = 0, y = Lim[4] - 0.02, label = Text, 
             size = 16, color="black") +
    theme(axis.text.x  = element_text(size = 22, face = "bold", colour = "black"),
          axis.text.y  = element_text(size = 22, face = "bold", colour = "black"), 
          axis.title.x = element_text(size = 24, face = "bold"),
          axis.title.y = element_text(size = 24, face = "bold"),
          legend.position = "top", legend.justification = "left",
          legend.text  = element_text(size = 28, face = "bold"), 
          legend.title = element_blank() ) +
    guides(colour = guide_legend(nrow = 3)) +
    scale_color_manual(values = Cols, labels = LabelsC[-2])
  return(p) }

# Plots of multilevel & main ecological estimates for main scenarios for binary outcome
BpltApp1 <- function(modB, Text){
  modB <-  modB[modB$Group != "XZN",]
  Cols <<- Colors[-2]
  Lim  <<- c(-0.02, max(modB$X) + 0.05, min(-0.02, modB$Y), max(modB$Y) + 0.05)
  p <- ggplot(modB, aes(x = X, y = Y)) + theme_classic() +
    geom_jitter(aes(colour = Group), size = 4, shape = 18, 
                position = position_jitter(width = 0.003, height = 0.003, seed = 13)) +
    geom_smooth(aes(colour = Group), linewidth = 1, method = 'lm', 
                formula = y ~ poly(x,2), se = FALSE, alpha = 0.1, 
                position = position_jitterdodge(dodge.width = 0.001)) + 
    geom_abline(intercept = 0, slope = 1, color = "grey", 
                linetype = "dashed", linewidth = 1) + xlab(XlabB) + ylab(Ylab) +
    xlim(Lim[1], Lim[2]) + ylim(Lim[3], Lim[4]) + 
    annotate(geom = "text", x = 0, y = Lim[4] - 0.02, label = Text, 
             size = 16, color="black") +
    theme(axis.text.x  = element_text(size = 22, face = "bold", colour = "black"),
          axis.text.y  = element_text(size = 22, face = "bold", colour = "black"), 
          axis.title.x = element_text(size = 24, face = "bold"),
          axis.title.y = element_text(size = 24, face = "bold"),
          legend.position = "top", legend.justification = "left",
          legend.text  = element_text(size = 28, face = "bold"), 
          legend.title = element_blank() ) +
    guides(colour = guide_legend(nrow = 3)) +
    scale_color_manual(values = Cols, labels = LabelsB[-2])
  return(p) }

# Plots of multilevel & main ecological estimates for additional scenarios for continuous outcome
CpltTxt2 <- function(modC, Text){
  Jitter <- if_else(NROW(modC) < 100, 0, 0.002)
  Cols   <- Colors[c(1,3)]
  modC[modC$Group == "MLX",]$X <- modC[modC$Group == "MLX",]$X - Jitter
  modC[modC$Group == "XZN",]$X <- modC[modC$Group == "XZN",]$X + Jitter
  if (Text == "4b") { Lim <- c(-2*Jitter, 0.5+2*Jitter, -0.26, 0.72)} 
  p <- ggplot(modC, aes(x = X, y = Y)) + theme_classic() +
    geom_jitter(aes(colour = Group), size = 1, shape = 18, 
                position = position_jitter(width = Jitter, seed = 13)) +
    geom_smooth(aes(colour = Group), linewidth = 1, method = 'lm', 
                formula = y ~ x, se = FALSE) + 
    geom_abline(intercept = 0, slope = 1, color = "grey", 
                linetype = "dashed", linewidth = 1) + 
    xlim(Lim[1], Lim[2]) + ylim(Lim[3], Lim[4]) + xlab(XlabC) + ylab(Ylab) + 
    annotate(geom = "text", x = 0, y = Lim[4], label = Text, 
             size = 14, color="black") +
    theme(axis.text.x  = element_text(size = 22, face = "bold", colour = "black"),
          axis.text.y  = element_text(size = 22, face = "bold", colour = "black"), 
          axis.title.x = element_text(size = 24, face = "bold"),
          axis.title.y = element_text(size = 24, face = "bold"),
          legend.position = "top", legend.justification = "left",
          legend.text  = element_text(size = 28, face = "bold"), 
          legend.title = element_blank() ) +
    guides(colour = guide_legend(nrow = 1)) +
    scale_color_manual(values = Cols, labels = LabelsC[1:2]) +
    guides(color = guide_legend(override.aes = list(size = 4))) 
  return(p) }

# Plots of multilevel & main ecological estimates for additional scenarios for binary outcome
BpltTxt2 <- function(modB, Text){
  Cols   <- Colors[c(1,3)]
  Jitter <- if_else(NROW(modB) < 100, 0, max(modB$X)/500)
  modB[modB$Group == "MLX",]$X <- modB[modB$Group == "MLX",]$X - Jitter
  modB[modB$Group == "XZN",]$X <- modB[modB$Group == "XZN",]$X + Jitter
  if (Text == "4a") { Lim <- c(-2*Jitter, 1.34+2*Jitter, -50, 50)} 
  if (Text == "4c") { Lim <- c(-2*Jitter, 1.34+2*Jitter, -18, 13)} 
  p <- ggplot(modB, aes(x = X, y = Y)) + theme_classic() +
    geom_jitter(aes(colour = Group), size = 1, shape = 18, 
                position = position_jitter(width = Jitter, seed = 13)) +
    geom_smooth(aes(colour = Group), linewidth = 1, method = 'lm', 
                formula = y ~ x, se = FALSE) + 
    geom_abline(intercept = 0, slope = 1, color = "grey", 
                linetype = "dashed", linewidth = 1) + 
    xlim(Lim[1], Lim[2]) + ylim(Lim[3], Lim[4]) + xlab(XlabB) + ylab(Ylab) + 
    annotate(geom = "text", x = 0, y = Lim[4], label = Text, 
             size = 14, color="black") +
    theme(axis.text.x  = element_text(size = 22, face = "bold", colour = "black"),
          axis.text.y  = element_text(size = 22, face = "bold", colour = "black"), 
          axis.title.x = element_text(size = 24, face = "bold"),
          axis.title.y = element_text(size = 24, face = "bold"),
          legend.position = "top", legend.justification = "left",
          legend.text  = element_text(size = 28, face = "bold"), 
          legend.title = element_blank() ) +
    guides(colour = guide_legend(nrow = 1)) +
    scale_color_manual(values = Cols, labels = LabelsB[1:2]) +
    guides(color = guide_legend(override.aes = list(size = 4))) 
  return(p) }

# write graph to disk in jpeg format
SaveJpg      <- function(plt, name) { 
  ggsave(plt, file = paste0(name,".jpg"), width = 384, height = 216, units = "mm", limitsize = FALSE) } 

## FUNCTIONS  - SETUP GRAPHICAL LABELS & PARAMETERS ----------------------------
Colors  <- c("black","#0000FF","#FF6600","#009900","#FF0033","#33CCFF","#9933FF")
TextC   <- c("A", "C", "E", "G")
TextB   <- c("B", "D", "F", "H")
Ylab    <- quote("Model Estimated Standardised Path Coefficient")
XlabC   <- quote(bold(paste("Simulated individual-level path coefficient ", 
                            bolditalic(rho[italic("7")]), " for continuous outcome ", 
                            bolditalic("Y") )))
XlabB   <- quote(bold(paste("Simulated individual-level path coefficient ", 
                            bolditalic(rho[italic("7")]), " for binary outcome ",
                            bolditalic("Y") )))
LabelE  <- c(quote(bold(paste("Model 2: ",
                              bolditalic("Y"[italic("j")]), "~", 
                              bolditalic("X"[italic("j")]), "+", 
                              bolditalic("Z"[italic("j")]), "+", 
                              bolditalic("N"[italic("j")])))),
             quote(bold(paste("Model 3: ",
                              bolditalic("Y"[italic("j")]), "~", 
                              bolditalic("X"[italic("j")]), "+", 
                              bolditalic("Z"[italic("j")]), "+", 
                              bolditalic("1"), "/",
                              bolditalic("N"[italic("j")])))), 
             quote(bold(paste("Model 4: ",
                              bolditalic("Y"[italic("j")]), "/", 
                              bolditalic("N"[italic("j")]), "~", 
                              bolditalic("X"[italic("j")]), "/", 
                              bolditalic("N"[italic("j")]), "+", 
                              bolditalic("Z"[italic("j")]), "   "))),
             quote(bold(paste("Model 5: ",
                              bolditalic("Y"[italic("j")]), "/", 
                              bolditalic("N"[italic("j")]), "~", 
                              bolditalic("X"[italic("j")]), "/", 
                              bolditalic("N"[italic("j")]), "+", 
                              bolditalic("Z"[italic("j")]), "+",
                              bolditalic("N"[italic("j")]),"   "))), 
             quote(bold(paste("Model 6: ",
                              bolditalic("Y")[italic("j")], "/", 
                              bolditalic("N"[italic("j")]), "~", 
                              bolditalic("X"[italic("j")]), "/", 
                              bolditalic("N"[italic("j")]), "+", 
                              bolditalic("Z"[italic("j")]), "+",
                              bolditalic("1"), "/",
                              bolditalic("N"[italic("j")])))), 
             quote(bold(paste("Model 7: ",
                              bolditalic("Y"[italic("j")]), "~", 
                              bolditalic("X"[italic("j")]), "+", 
                              bolditalic("OffSet(log("),
                              bolditalic("N"[italic("j")]), 
                              bolditalic("))") ))) )
LabelM  <- c(quote(bold(paste("Model 1: ",
                              bolditalic("Y")[italic("i")], "~", 
                              bolditalic("X"[italic("i")]), "+", 
                              bolditalic("Z"[italic("i")]), "+", 
                              bolditalic("N"[italic("j")])))))
LabelsC  <- c(LabelM, LabelE[1:5])
LabelsB  <- c(LabelM, LabelE)

## FUNCTIONS  - MISCELLANEOUS ROUTINES & PARAMETER ASSIGNMENTS -----------------
# reorder matrix according to Names
Reorder_Mat  <- function(X, Names) { 
  NewOrder <- sapply(colnames(X), function(w) { which(w==Names) } )
  return(X[order(NewOrder),order(NewOrder)]) } 

# create median function that ignores NAs
median.na <- \(x) median(x,   na.rm = TRUE)

# assign names to all 11 scenarios
Xnames    <- c(paste0("Con-Con-", 1:4), paste0("Con-Bin-Reg-", 1:4), "Con-Bin-Low", "Bin-Con", "Bin-Bin")

## FUNCTIONS  - CLUSTER PROGRAMS ------------------------------------------------
clusterExport(cl, c("GenData1", "GenData2", "GenData3", "Factor.Analysis",      # export functions to the clusters
                    "AggData", "MLmods", "GetAllConEst", "GetAllBinEst", 
                    "GetMinConEst", "GetMinBinEst"))
clusterExport(cl, c("nSims", "nPop", "nClust", "ClustSize", "pX_Y", "vOrder",   # export variable to the clusters
                    "Means", "Nvar"))

################################################################################
## MAIN PROGRAM - TUNE GenData -------------------------------------------------
print(paste0("Tuning: Y-prevalance ", YPrev, " - ", OptN, " repeats"))          # circa 43 hours for 5k 
FileName  <- paste0(Results, "Opt Con Bin Results ", OptN, ".csv")              # label & date the output file
YPrev     <- 0.1
if (!file.exists(FileName)) { Opt <- GetOptnF(1:4, pX_Y, 1)                     # tune GenData for prev = 0.1
  write.table(Opt, file = FileName, sep = ",", row.names = FALSE) }             # save optimisation & manually choose 

print(paste0("Tuning: Y-prevalence ", YPrev, " - ", OptN, " repeats"))          # circa 6 hours for 5k
FileName  <- paste0(Results, "Opt Con Bin Low Prev Results ", OptN, ".csv")
YPrev     <- 0.001
if (!file.exists(FileName)) { Opt <- GetOptnF(4, pX_Y, 1)
  write.table(Opt, file = FileName, sep = ",", row.names = FALSE) }

print(paste0("Tuning: Binary L-confounding continuous Y - ", OptN, " repeats")) # circa 6 hours for 5k
FileName  <- paste0(Results, "Opt Bin Con Results ", OptN, ".csv")
YPrev     <- 0.1
if (!file.exists(FileName)) { Opt <- GetOptnF(4, pX_Y, 2)
  write.table(Opt, file = FileName, sep = ",", row.names = FALSE) }

print(paste0("Tuning: Binary L-confounding binary Y - ", OptN, " repeats"))     # circa 5 hours for 5k
FileName  <- paste0(Results, "Opt Bin Bin Results ", OptN, ".csv")
YPrev     <- LPrev <- 0.1
if (!file.exists(FileName)) { Opt <- GetOptnF(4, pX_Y, 3)
  write.table(Opt, file = FileName, sep = ",", row.names = FALSE) }

## MAIN PROGRAM - MANUALLY CREATE OPTIMAL INPUT FOR NON-NORMALSIMULATIONS ------
################################################################################
## MAIN PROGRAM - SIMULATE & ANALYSE ALL SCENARIOS -----------------------------
print(paste0("Sims: Continuous confounding, continuous Y - ", nSims, " reps"))  # circa 2 hours for 1K
FileName  <- paste0(Results, "Est Con Con ", nSims, ".csv")                     # resulting estimates file
if (!file.exists(FileName)) { EstCC <- GetEstimates(1:4, pX_Y, NA, "N")         # run continuous outcome simulations
  write.table(EstCC, file = FileName, sep = ",", row.names = FALSE) }           # save model estimates

print(paste0("Sims: Continuous confounding, binary Y - ", nSims, " reps"))      # circa 48 hours for 1k
FileName  <- paste0(Results,          "Est Con Bin ", nSims, ".csv")            # do each configuration separately
Optimal   <- read.csv(paste0(Results, "Opt Con Bin Set.csv"))                   # optimal settings for GenData
Optimal$n <- Optimal[,OptSet[max(which(OptSet %in% names(Optimal)))]]           # get best available optimal settings
Optimal   <- unique(Optimal |> select(Conf, pX_Y, n))                           # minimal information needed
YPrev     <- 0.1                                                                # 10% outcome prevalence
if (!file.exists(FileName)) { EstCB <- GetEstimates(1:4, pX_Y, Optimal, "Y")    # run binary outcome simulations
  write.table(EstCB, file = FileName, sep = ",", row.names = FALSE) }

print(paste0("Sims: Continuous confounding, low prev Y - ", nSims, " reps"))    # circa 16.7 hours for 1k
FileName  <- paste0(Results,          "Est Con Bin Low Prev ", nSims, ".csv")
Optimal   <- read.csv(paste0(Results, "Opt Con Bin Low Prev Set.csv"))
Optimal$n <- Optimal[,OptSet[max(which(OptSet %in% names(Optimal)))]]
Optimal   <- unique(Optimal |> select(Conf, pX_Y, n))
YPrev     <- LowPrev
if (!file.exists(FileName)) { EstCR <- GetEstimates(4, pX_Y, Optimal, "R")      # 'R' for Rare
  write.table(EstCR, file = FileName, sep = ",", row.names = FALSE) }

print(paste0("Sims: Binary L-confounding, continuous Y - ", nSims, " reps"))    # circa 1 hour for 1k
FileName  <- paste0(Results,          "Est Bin Con ", nSims, ".csv")
Optimal   <- read.csv(paste0(Results, "Opt Bin Con Set.csv"))
Optimal$n <- Optimal[,OptSet[max(which(OptSet %in% names(Optimal)))]]
Optimal   <- unique(Optimal |> select(Conf, pX_Y, n))
LPrev     <- 0.1
if (!file.exists(FileName)) { EstBC  <- GetEstimates(4, pX_Y, Optimal, "L")
  write.table(EstBC, file = FileName, sep = ",", row.names = FALSE) }

print(paste0("Sims: Binary L-confounding, binary Y - ", nSims, " reps"))        # circa 18 hours for 1k
FileName  <- paste0(Results,          "Est Bin Bin ", nSims, ".csv")
Optimal   <- read.csv(paste0(Results, "Opt Bin Bin Set.csv"))
Optimal$n <- Optimal[,OptSet[max(which(OptSet %in% names(Optimal)))]]
Optimal   <- unique(Optimal |> select(Conf, pX_Y, n))
YPrev     <- LPrev <- 0.1
if (!file.exists(FileName)) { EstBB <- GetEstimates(4, pX_Y, Optimal, "B")
  write.table(EstBB, file = FileName, sep = ",", row.names = FALSE) }

################################################################################
## MAIN PROGRAM - STACK ALL MODELS & EXAMINE ML CONVERGENCE ISSUES -------------
# Stack all 11 models for the 11 scenarios executed
OrigXX      <- vector(mode = "list", length = 11)                               # store all 11 models
Con         <- read.csv(paste0(Results, "Est Con Con ", nSims, ".csv"))         # main continuous models
Bin         <- read.csv(paste0(Results, "Est Con Bin ", nSims, ".csv"))         # main binary models
EstCR       <- read.csv(paste0(Results, "Est Con Bin Low Prev ", nSims, ".csv"))# Scenario 4 extensions
EstBC       <- read.csv(paste0(Results, "Est Bin Con ", nSims, ".csv"))  
EstBB       <- read.csv(paste0(Results, "Est Bin Bin ", nSims, ".csv"))
for (mod in 1:4) OrigXX[[mod]]   <- Con[Con$Conf == mod,]                       # get ML-true & SL-true values for all models
for (mod in 1:4) OrigXX[[mod+4]] <- Bin[Bin$Conf == mod,]                       # to report biases & remove bias at pX_Y = 0
OrigXX[[9]]  <- EstCR |> select(Conf:XZN, MLX:NS)                               # remove NA column needed for df orientation
OrigXX[[10]] <- EstBC |> select(Conf:XZN, MLX:NS)
OrigXX[[11]] <- EstBB |> select(Conf:XZN, MLX:NS); sapply(OrigXX, NROW)         # check all ~6k
saveRDS(OrigXX, file = paste0(Results, "Raw Models.RDS"), compress = FALSE)     # save all raw models

# check how ML models differed between those with / without warnings
OrigXX    <- readRDS(paste0(Results, "Raw Models.RDS"))                         # read in all raw models
Diff      <- lapply(1:11, \(iMod) { 
  Mod     <- OrigXX[[iMod]]                                                     # get differences for ML models with NS warning
  OKNS    <- lapply(pX_Y, \(jPath) {                                            # get estimates for OK & NS models
    OK    <- Mod[round(Mod$pX_Y,1) == round(jPath,1) & Mod$NS == "OK",]$MLX
    NS    <- Mod[round(Mod$pX_Y,1) == round(jPath,1) & Mod$NS == "NS",]$MLX
    OK_NS <- 0                                                                  # difference between OK & NS models
    if (NROW(NS) == 0) State <- "OK"                                            # no NS models - results are good
    if (NROW(OK) != 0 & NROW(NS) != 0) OK_NS <- median(OK)-median(NS)           # difference in median of estimates
    data.frame(Model = Xnames[iMod], pX_Y = jPath, OK = NROW(OK), 
               NS = NROW(NS), OK_NS = OK_NS) })
  do.call(rbind, OKNS) })
DiffML    <- do.call(rbind, Diff); DiffML
round(100*mean(DiffML[c(1:24,55:60),"NS"])/1000,1); round(100*mean(DiffML[c(25:30,49:55),"NS"])/1000,1)
max(DiffML[c(1:24,55:60),"OK_NS"])
max(DiffML[c(25:30,49:55),"OK_NS"])
write.table(DiffML, file = paste0(Results, "DiffML.csv"), sep = ",", row.names = FALSE)

## MAIN PROGRAM - DERIVE CORRECT BINARY X-VALUES & GET SIMULATION BIASES -------
# assume median ML-true value for all pX_Y = 0 models is simulation bias
# assume median ML-true for Scenario 1 binary outcome is indicative of true x-values 
OrigXX    <- readRDS(paste0(Results, "Raw Models.RDS"))                         # read in all raw models
True      <- lapply(1:11, \(iMod) {
  Orig    <- OrigXX[[iMod]]                                                     # select each scenario
  sapply(pX_Y, \(jPath) {                                                       # get raw median x-values
    median.na(Orig[round(Orig$pX_Y,1) == round(jPath,1),]$MLtrue) }) })
TrueX     <- data.frame(pX_Y = pX_Y, do.call(cbind, True))                      # summary of all x-values
names(TrueX)[-1] <- Xnames; #round(TrueX, 2)                                    # label with model names & check
TrueXbin  <- round(sapply(pX_Y, \(jPath) {
  median.na(OrigXX[[5]][round(OrigXX[[5]]$pX_Y,1) == round(jPath,1),]$MLtrue) }), 2)
SimBias   <- data.frame(Model = Xnames, SimBias = round(t(TrueX[1,-1]),3))      # save simulation biases
row.names(SimBias) <- NULL; names(SimBias)[2] <- "SimBias"
write.table(TrueXbin, file = paste0(Results, "Binary X-values.csv"),   sep = ",", row.names = FALSE)
write.table(SimBias,  file = paste0(Results, "Simulation Biases.csv"), sep = ",", row.names = FALSE)

## MAIN PROGRAM - APPLY CORRECT X-VALUES & REMOVE SIMULATION BIASES ------------
# create a new simulation-bias corrected dataset with 'true' x-values included
TrueXbin  <- read.csv(paste0(Results, "Binary X-values.csv"))                   # read in true X-values
SimBias   <- read.csv(paste0(Results, "Simulation Biases.csv"))                 # read in simulation biases
FixRaw  <- lapply(1:11, \(iMod) {
  Orig  <- OrigXX[[iMod]]                                                       # select each model
  Fix   <- Orig |> select(Conf:pX_Y, XZN:MLX); Fix$X <- NA                      # add 'true' X-value
  for (jPath in 1:6) {
    if (iMod %in% c(5:9, 11)) {                                                 # distinguish continuous & binary models
      Fix[round(Fix$pX_Y,1) == round(pX_Y[jPath],1),]$X <- TrueXbin[jPath,]     # assign 'true' x-values to binary models
    } else { 
      Fix[round(Fix$pX_Y,1) == round(pX_Y[jPath],1),]$X <- pX_Y[jPath] }        # assign 'true' x-values to continuous models
    if (iMod %in% c(9:11)) {
      Fix[round(Fix$pX_Y,1) == round(pX_Y[jPath],1),]$MLX <-                    # remove simulation bias for ML model
        Fix[round(Fix$pX_Y,1) == round(pX_Y[jPath],1),]$MLX - SimBias[iMod,2]
      Fix[round(Fix$pX_Y,1) == round(pX_Y[jPath],1),]$XZN <-                    # remove simulation bias for ecol model
        Fix[round(Fix$pX_Y,1) == round(pX_Y[jPath],1),]$XZN - SimBias[iMod,2] } }
  if (iMod %in% c(5:8)) Fix[,c("rXZ", "rXZN", "rXZiN")] <-                      # scale binary ratio estimates by nClust 
    Fix[,c("rXZ", "rXZN", "rXZiN")] / nClust
  Fix })
saveRDS(FixRaw, paste0(Results, "Fixed Raw Models.RDS"), compress = FALSE)      # save all fixed raw models

## MAIN PROGRAM - OBTAIN ML & ECOL MODEL ESTIMATE BIASES & HETEROGENEITY -------
# examine ML & main Ecol analyses for bias & heterogeneity
TrueXbin  <- read.csv(paste0(Results, "Binary X-values.csv"))                   # read in true X-values
FixRaw    <- readRDS(paste0(Results, "Fixed Raw Models.RDS"))                   # read in all fixed raw models
Bias      <- lapply(1:11, \(iMod) {
  Mod     <- FixRaw[[iMod]]                                                     # select each model raw values
  Metrics <- lapply(1:6, \(jPath) {
    Eval  <- Mod[round(Mod$pX_Y,1) == round(pX_Y[jPath],1),]                    # select effect-size evaluation
    Vars  <- Eval |> select(MLX, XZN)                                           # select main vars for each path
    if (iMod %in% c(1:4,10)) Truth <- pX_Y[jPath]                               # truth is the raw path coefficient 
    if (iMod %in% c(5:9,11)) Truth <- TrueXbin[jPath,1]                         # or truth is new true X-value 
    Errs  <- Vars - Truth                                                       # calculate model errors
    Med   <- data.frame(t(apply(Errs, 2, median))) |>                           # median error from truth = bias
      rename(biasML = MLX, biasEcol = XZN)
    SD    <- data.frame(t(apply(Vars - Truth, 2, sd))) |>                       # sd of error from truth = heterogeneity
      rename(sdML   = MLX, sdEcol   = XZN)
    data.frame(Model = Xnames[iMod], pX_Y = pX_Y[jPath], Med, SD) })            # store bias & heterogeneity values
    do.call(rbind, Metrics) })
Biases    <- do.call(rbind, Bias)
write.table(Biases, file = paste0(Results, "Biases.csv"), sep = ",", row.names = FALSE)

## MAIN PROGRAM - CREATE SUMMARY DATA OF ESTIMATES FOR GRAPHICAL DISPLAY -------
# create summary data for graphical display
FixRaw  <- readRDS(paste0(Results, "Fixed Raw Models.RDS"))                     # read in all fixed raw models
FixSum  <- lapply(1:11, \(iMod) {
  Mod   <- FixRaw[[iMod]] |> select(pX_Y, XZN:X)                                # select each model & relevant variables
  Sum   <- lapply(pX_Y, \(jPath) {                                              # get median summary estimates
    data.frame(Conf = iMod, t(apply(Mod[round(Mod$pX_Y,1) == round(jPath,1),], 2, median.na))) })
  do.call(rbind, Sum) })
saveRDS(FixSum, paste0(Results, "Fixed Summary Models.RDS"), compress = FALSE)  # save all fixed summary models

## MAIN PROGRAM - CREATE GRAPHICAL DISPLAY OF MAIN 4 SCENARIOS -----------------
CpltTxt <- CpltApp <- BpltTxt <- BpltApp <- vector(mode = "list", length = 4)   # store main scenarios plots for text & appendix
FixSum  <- readRDS(paste0(Results, "Fixed Summary Models.RDS"))                 # read in all fixed summary estimates 

for (iConf in Configs) {                                                        # generate plots for each main continuous outcome
  WideCC  <- FixSum[[iConf]] |> select(pX_Y, MLX, XZN:rXZiN)                    # select relevant variables
  LongCC  <- gather(WideCC, Group, Y, MLX:rXZiN, factor_key = TRUE)             # stack results 
  CpltTxt[[iConf]] <- CpltTxt1(LongCC, TextC[iConf])                            # send data & title to text chart function
  CpltApp[[iConf]] <- CpltApp1(LongCC, TextC[iConf])                            # send data & title to Appendix chart function
  SaveJpg(CpltTxt[[iConf]], paste0(Plots, "CON_PLOT_TXT_", iConf))              # save text charts in jpeg format
  SaveJpg(CpltApp[[iConf]], paste0(Plots, "CON_PLOT_APP_", iConf)) }            # save appendix charts in jpeg format

for (iConf in Configs) {
  WideCB  <- FixSum[[iConf + 4]] |> select(X, MLX, XZN:XZoffN)
  LongCB  <- gather(WideCB, Group, Y, MLX:XZoffN, factor_key = TRUE)
  BpltTxt[[iConf]] <- BpltTxt1(LongCB, TextB[iConf])
  BpltApp[[iConf]] <- BpltApp1(LongCB, TextB[iConf])
  SaveJpg(BpltTxt[[iConf]], paste0(Plots, "BIN_PLOT_TXT_", iConf))
  SaveJpg(BpltApp[[iConf]], paste0(Plots, "BIN_PLOT_APP_", iConf)) }
#CpltTxt; CpltApp; BpltTxt; BpltApp

## MAIN PROGRAM - CREATE GRAPHICAL SUMMARIES OF EXTENDED SCENARIO 4 ------------
FixRaw      <- readRDS(paste0(Results, "Fixed Raw Models.RDS"))                 # read in all fixed raw estimates
Eplot       <- vector(mode = "list", length = 3)                                # store additional scenario 4 plots
WideCR      <- FixRaw[[9]]  |> select(X, MLX, XZN)
LongCR      <- gather(WideCR, Group, Y, MLX:XZN, factor_key = TRUE)
Eplot[[1]]  <- BpltTxt2(LongCR, "4a"); SaveJpg(Eplot[[1]], paste0(Plots, "EXTRA_PLOT_4a"))
WideBC      <- FixRaw[[10]] |> select(pX_Y, MLX, XZN) |> rename(X = pX_Y)
LongBC      <- gather(WideBC, Group, Y, MLX:XZN, factor_key = TRUE)
Eplot[[2]]  <- CpltTxt2(LongBC, "4b"); SaveJpg(Eplot[[2]], paste0(Plots, "EXTRA_PLOT_4b"))
WideBB      <- FixRaw[[11]] |> select(X, MLX, XZN)
LongBB      <- gather(WideBB, Group, Y, MLX:XZN, factor_key = TRUE)
Eplot[[3]]  <- BpltTxt2(LongBB, "4c"); SaveJpg(Eplot[[3]], paste0(Plots, "EXTRA_PLOT_4c"))
#Eplot

## END PROGRAM -----------------------------------------------------------------
stopCluster(cl)

# stop benchmarking time
benchmark_time$end <- Sys.time()
print("Duration of Program:")
print(round(benchmark_time$end - benchmark_time$start), 2)

