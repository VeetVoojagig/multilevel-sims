# Meta

**Authors:** MS Gilthorpe with input from L Kakampakou. Support from 
A Hoehn for reproducibility element.

**Version:** 1.0

**Date:**  2025-02-17

# About 
Reproducibility Pack for the paper "Simulating hierarchical data to assess 
the utility of ecological versus multilevel analyses in obtaining individual-level 
causal effects." (BMC Medical Research Methodology, 2025)

# How do I run the code? 
Running the code is very simple, you first need to download the folder 
containing all files and extract them into any folder on your machine - 
ideally locally (e.g. "C:/my_folder/). Please note that working of network
drives and/or network installations for R can lead to incompatibilities.  
Be aware that the program has not been tested for network drives. Close all 
tabs and RStudio. Then open "multilevel-sims.Rproj" file in the main folder. 
This will  open RStudio in project mode (check top left bar and ensure that 
"multilevel-sims" is displayed there. Within R Studio, open "run_ecological_sims.R" 
file and run it. All analyses will be run automatically and the corresponding 
output will be created in the figures folder.

# Do I need to specify a working directory manually?
This is not required. All file paths are defined relative, just ensure the 
file structure provided in the example is reproduced.

# Do I need to install packages manually?
This is not required. The program will check automatically for all required 
libraries in their correct versions. If required (and only if required), it 
will download and install missing libraries in their correct versions. Therefore, 
running code for the very first time might take a bit longer. All subsequent 
runs will not require this and the program will run much faster. 

# Specifics for Unix Systems
If you encounter that some packages cannot be installed it might be required to 
understand the specific dependencies of each package (and its dependencies) 
in more detail. Examples;

"MBESS" requires "cmake" which often needs to be installed manually through 
the terminal: "sudo apt install cmake" (Linux Mint)

"dagitty" uses the package "V8" which requires libnode-dev. Install through
the terminal: "sudo apt install libnode-dev" (Linux Mint)

# Code was tested on the following machines:

See RCode for specific packages and their versions

R version 4.4.2 (2024-10-31 ucrt) -- "Pile of Leaves"

Windows: x86_64-w64-mingw32/x64; Windows 10 with 32GB & i7 in 5min

Linux: x86_64-pc-linux-gnu; Mint 20.3 with 8GB & i3 in 15min

# How do I report bugs?
send an email to: m.s.gilthorpe@leedsbeckett.ac.uk